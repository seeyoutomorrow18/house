<template>
    <div class="imgbox-loupan">
        <img alt="" src="https://www.apyfc.com/uploadfiles/201903/19/201903191418540214.jpg" lazy="loaded">
    </div>
</template>

<script>
export default {
    
}
</script>

<style lang='scss' scoped>
.imgbox-loupan{
    height: 3.08333rem;
    width: 100%;
    img{
        display: block;
        height: 100%;
        width: 100%;
    }
}
</style>