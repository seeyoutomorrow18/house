<template>
    <section  class="tool-box">
        <div  class="mr">
            <img  src="https://newhouse.apyfc.com/img/img_home_page_tool_housing_policy@3x.88174790.png" alt="">
        </div>
        <div>
            <img  src="https://newhouse.apyfc.com/img/img_home_page_tool_mortgage_calculator@3x.54185e4d.png" alt="">
        </div>
    </section>
</template>


<script>
export default {
    
}
</script>


<style lang='scss' scoped>
.tool-box{
    align-items: center;
    background: #fff;
    display: flex;
    justify-content: space-between;
    margin-bottom: 10.417px;
    padding: 14.583px 13.889px;
    .mr{
        margin-right: 10.417px;
    }
    img{
        display: block;
        flex: 1;
        height: 100%;
        width: 100%;
    }
}
</style>