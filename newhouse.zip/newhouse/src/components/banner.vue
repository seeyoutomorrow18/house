<template>
    <div class="stance-img">
        <img src="https://www.apyfc.com/uploadfiles/201903/11/201903111423131762.jpg" lazy="loaded">
    </div>
</template>

<script>
export default {
    
}
</script>


<style lang='scss' scoped>
.stance-img{
    border-radius: 1.5px;
    height: 78.124px;
    margin-bottom: 13.89px;
    overflow: hidden;
    padding: 0 13.89px;
    img{
        border-radius: 13.95px;
        display: block;
        height: 100%;
        overflow: hidden;
        width: 100%;
    }
}
</style>