export default {
    state:{
        user:{
            // Authorization,
            // username

        }
    },
    matetions:{
        login(state){
            state.user
        },
        logout(state){
            state.user
        }
    },

}